function [ sd ] = squareddistance2d( x, m )
    sd = (x - m)'*(x-m);
end