function [ sd ] = squareddistance( x, m )
sd = (x - m)^2;
end

